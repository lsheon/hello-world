package net.daum.javacafe.event;

/**
 * @author SongJiHoon
 */
public interface NIOEvent {
	
	public int ACCEPT_EVENT = 1;
	public int READ_EVENT = 2;

}
