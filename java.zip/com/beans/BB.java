package com.beans;

public class BB {
	public BB() {
		System.out.println("BB()...");
	}
}
