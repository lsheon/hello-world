package com.beans;

import java.util.List;
import java.util.Map;

public class AA {
	String name ="";
	BB bb = null;
	List<BB> list = null;
	private Map<String, String> maps = null;
	
	public AA() {
		System.out.println("AA() 1...");
	}
	
	public AA(BB bb) {
		System.out.println("AA() 2...");
		this.bb = bb;
	}
	
	public AA(String s1, String s2) {
		System.out.println("AA() 3...");
		System.out.println("s1 ?? "+s1);
		System.out.println("s2 ?? "+s2);
	}
	
	public void setBb(BB bb) {
		System.out.println("AA setBb()..");
		this.bb = bb;
	}
	
	public void setList(List<BB> list) {
		System.out.println("AA setList()..");
		this.list = list;
	}
	
	public List<BB> getList() {
		return this.list;
	}
	
	public void setMaps(Map<String, String> map) {
		System.out.println("AA setMaps()..");
		this.maps = map;		
	}
	
	public String getValue(String key) {
		return maps.get(key);
	}
}
