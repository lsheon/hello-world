package com.tcp;

import java.io.DataOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class TcpClientSimple {
	public static void main(String[] args) {
		try{
			Socket socket =new Socket("127.0.0.1", 10001);
			OutputStream out = socket.getOutputStream();
			DataOutputStream dout = new DataOutputStream(out);
			
			int i = 0;
			
			while((i = System.in.read()) != -1) {
				out.write(i);
				out.flush();
			}
			
			//dout.writeUTF("가나");
			
			socket.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
