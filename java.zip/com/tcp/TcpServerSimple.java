package com.tcp;

import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServerSimple {
	public static void main(String[] args) {
		try{
			ServerSocket serverSocket = new ServerSocket(10001);
			
			Socket socket = serverSocket.accept();
			InputStream in = socket.getInputStream();
			
			
			int i = 0;
			while((i = in.read()) != -1) {
				System.out.println("Server i ?? "+i);
			}
			
//			byte[] readByte = new byte[2048];
//			int cnt = 0;
//			while( (cnt = in.read(readByte)) != -1) {
//				System.out.println(new String(readByte, "utf-8"));
//			}
			
			//euc-k : 176, 161
			//utf-8 : 234, 176, 128
			//iso-8859-1 : 63
			
		}catch(Exception e) {
			
		}
	}
}
