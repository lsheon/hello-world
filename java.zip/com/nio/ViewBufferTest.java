package com.nio;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public class ViewBufferTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteBuffer buf = ByteBuffer.allocate(10);
		
//		while(buf.hasRemaining()){
//			System.out.println(buf.get()+" ");
//		}
		
		buf.position(0);
		
		System.out.println("position ?? "+buf.position()+", limit ?? "+
				buf.limit()+", capacity ?? "+buf.capacity());
		
		IntBuffer ib = buf.asIntBuffer();
		
		System.out.println("position ?? "+ib.position()+", limit ?? "+
		ib.limit()+", capacity ?? "+ib.capacity());
		
		//ib.put(1024).put(2048);
		ib.put(1);
		ib.put(1);
		
		//System.out.println(ib.get(0)+", "+ib.get(1));
		
		while(buf.hasRemaining()) {
			System.out.println(buf.get()+" ");
		}
		
	}

}
