package com.nio;

public class NIOEvent {
	public static final int ACCEPT_EVENT = 1;
	public static final int READ_EVENT = 2;
}
