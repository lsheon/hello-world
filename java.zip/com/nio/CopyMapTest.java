package com.nio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class CopyMapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			long startTime = System.currentTimeMillis();
			
			FileInputStream fis = new FileInputStream("D:/TEST/src.avi");
			FileOutputStream fos = new FileOutputStream("D:/TEST/dest.avi");
			
			FileChannel in = fis.getChannel();
			FileChannel out = fos.getChannel();
			
			MappedByteBuffer m = in.map(FileChannel.MapMode.READ_ONLY, 0, in.size());
			out.write(m);
			
			System.out.println("Elapse Time : "+ (System.currentTimeMillis() - startTime));
			
			//31962
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
