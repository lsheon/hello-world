package com.nio;

import java.nio.ByteBuffer;

public class ByteBufferWriteTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 0x88EE;
		
		System.out.println(i);
		
//		byte[] byteArr = new byte[10];
//		
//		int i = 0;
//		
//		for(; i < byteArr.length;) {
//			byteArr[i++] = (byte)i;
//		}
//		
//		ByteBuffer buf1 = ByteBuffer.wrap(byteArr, 0, byteArr.length);
		
		//char : 2
		//int : 4
		//double : 8
		//float : 4
		//long : 8
		//short : 2
		
		ByteBuffer buf1 = ByteBuffer.allocate(10);
		buf1.putInt(3);
		
		System.out.println("buf1.position() ?? "+buf1.position());
		
		buf1.rewind();
		
		while(buf1.hasRemaining()) {
			System.out.println(buf1.getInt());
		}
		
		
		
//		ByteBuffer buf1 = ByteBuffer.allocate(10);
//		
//		buf1.put((byte)1);
//		buf1.put((byte)2);
//		buf1.put((byte)3);
//		buf1.put((byte)4);
//		buf1.put((byte)5);
//		buf1.put((byte)6);
//		buf1.put((byte)7);
//		buf1.put((byte)8);
//		buf1.put((byte)9);
//		buf1.put((byte)10);
//		
//		buf1.rewind();
//		
//		buf1.position(2);
//		
//		ByteBuffer buf = buf1.slice();
//		
//		buf1.rewind();
//		
//		buf.put(0, (byte)99);
//		
//		System.out.println("buf1.capacity() ?? "+buf1.capacity());
//		System.out.println("buf1.limit() ?? "+buf1.limit());
//		
//		System.out.println("buf.capacity() ?? "+buf.capacity());
//		System.out.println("buf.limit() ?? "+buf.limit());
//		
//		while(buf.hasRemaining()) {
//			System.out.println("buf.get() ?? "+buf.get());
//		}
//		
//		while(buf1.hasRemaining()) {
//			System.out.println("buf1.get() ?? "+buf1.get());
//		}
		
		
//		ByteBuffer buf = buf1.duplicate();
//		
//		buf.position(5);
//		
//		System.out.println("buf.position ?? "+buf.position());
//		System.out.println("buf1.position ?? "+buf1.position());
//		
//		while(buf.hasRemaining()) {
//			System.out.println("buf ?? "+buf.get());
//		}
//		
//		while(buf1.hasRemaining()) {
//			System.out.println("buf1 ?? "+buf1.get());
//		}
//		
//		buf.put(5, (byte)99);
//		
//		buf.rewind();
//		buf1.rewind();
//		
//		while(buf.hasRemaining()) {
//			System.out.println("buf ?? "+buf.get());
//		}
//		
//		while(buf1.hasRemaining()) {
//			System.out.println("buf1 ?? "+buf1.get());
//		}
		
		
		//buf1.flip();
		
//		ByteBuffer buf2 = ByteBuffer.allocate(10);
//		
//		buf2.put(buf1);
//		
//		System.out.println("buf2 position ?? "+buf2.position());
//		
//		buf2.flip();
//		
//		buf2.position(2);
//		
//		buf2.compact();
//		
//		buf2.rewind();
//		
//		while(buf2.hasRemaining()) {
//			System.out.println(buf2.get());
//		}
		
		
	}

}
