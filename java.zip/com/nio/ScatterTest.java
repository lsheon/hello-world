package com.nio;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ScatteringByteChannel;

public class ScatterTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileInputStream fin = new FileInputStream("D:/TEST/test.txt");
			ScatteringByteChannel channel = fin.getChannel();
			
			ByteBuffer header = ByteBuffer.allocate(9);
			ByteBuffer body = ByteBuffer.allocate(14);
			
			ByteBuffer[] buffers = {header, body};
			
			int readCount = (int) channel.read(buffers);
			channel.close();
			System.out.println("readCount ?? "+readCount);
			
			header.flip();			
			body.flip();
			
			byte[] b = new byte[header.limit()];
			
			header.get(b);
			System.out.println("Header ?? "+new String(b));
			
			byte[] bb = new byte[body.limit()];
			
			body.get(bb);
			
			System.out.println("Body ?? "+new String(bb));
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
