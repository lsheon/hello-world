package com.nio;

import java.nio.ByteBuffer;

public class SliceTest {
	public static void main(String[] args) {
		ByteBuffer buf = ByteBuffer.allocate(10);
		
		buf.put((byte)0).put((byte)1).put((byte)2).put((byte)3).put((byte)4).put((byte)5)
		.put((byte)6).put((byte)7).put((byte)8).put((byte)9);
		
		buf.position(3);
		buf.limit(9);
		
		ByteBuffer buf2 = buf.slice();
		
//		while(buf2.hasRemaining()) {
//			System.out.println(buf2.get());
//		}
		
		System.out.println("Position ?? "+buf2.position()+", Limit ?? "+buf2.limit()
		+", Capacity ?? "+buf2.capacity());
		
		while(buf2.hasRemaining()) {
			System.out.println(buf2.get()+" ");
		}
		
		buf.put(3, (byte)10);
		
		System.out.println("original ?? "+buf.get(3));
		System.out.println("slice ?? "+buf2.get(0));
		
		String s = "abc";
		byte[] b = s.getBytes();
		
		System.out.println("11111111111111111");
		
		for(int i =0; i<b.length; i++) {
			System.out.println(b[i]);
		}
		
		ByteBuffer bb = ByteBuffer.wrap(b, 0, b.length);
		bb.mark();	
		
		System.out.println("2222222222222222");
		
		while(bb.hasRemaining()) {
			System.out.println(bb.get());
		}
		
		b[0] = 'd';
		
		bb.reset();
		
		System.out.println("3333333333333333");
		
		while(bb.hasRemaining()) {
			System.out.println(bb.get());
		}
	}
}
