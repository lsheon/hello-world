package com.redis;

import redis.clients.jedis.Jedis;

public class HelloRedis {
	public static void main(String[] args) {
		Jedis jedis = new Jedis("127.0.0.1", 6379);
		
		String result = jedis.set("redisbook", "Hello redis");
		
		System.out.println(result);
		
		System.out.println(jedis.get("redisbook"));
		
		jedis.close();
	}
}
