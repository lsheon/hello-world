package com.bootstrap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.beans.AA;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//AbstractApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		ApplicationContext ctx = new FileSystemXmlApplicationContext("classpath:applicationContext.xml");
		AA aa = (AA)ctx.getBean("aaBean5");
		
		System.out.println(aa.getList().size());
		
		System.out.println(aa.getValue("name"));
	}

}
