package com.test.thread;

public class 죠인테스트 {
	public static void main(String[] args) {
		죠인테스트쓰레드 t = new 죠인테스트쓰레드();
		//t.setDaemon(true);
		t.start();
		
		try{
			t.join();
		}catch(Exception e) {
			
		}
		
		System.out.println("main Thread 종료");
	}
}
