package com.test.thread;

public class ThreadDemo implements Runnable {
   Thread t;

   ThreadDemo() {

   t = new Thread(this);
   // this will call run() function
   t.start();
   }

   public void run() {

   // returns the context ClassLoader for this Thread
   ClassLoader c = t.getContextClassLoader();

   // sets the context ClassLoader for this Thread
   t.setContextClassLoader(c);
   System.out.println("Class = " + c.getClass());
   System.out.println("Parent = " + c.getParent());
   }

   public static void main(String args[]) {
   new ThreadDemo();
   }
} 
