package com.test.thread;

public class 싱크러나이즈드메서드테스트 {
	private String s = null;
	
	public synchronized void setS(String s) {		
		this.s = s;
		notifyAll();
	}
	public synchronized String getS() throws Exception{
		if(this.s == null) {
			wait();
		}
		String cron = this.s;
		this.s = null;
		return cron;
	}
}
