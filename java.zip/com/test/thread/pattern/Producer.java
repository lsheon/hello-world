package com.test.thread.pattern;

public class Producer implements Runnable {
	private Queue queue = null;
	
	public Producer(Queue queue) {
		this.queue= queue;
	}
	
	public void run() {
		System.out.println("start Producer...");
		
		try{
			int i = 0;
			while (!Thread.currentThread().isInterrupted()) {
				queue.put(Integer.toString(i++));
				if(i == 10) {
					break;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("end Producer...");
		}
	}
	
	
}
