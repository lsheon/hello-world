package com.lsh;

import org.codehaus.jackson.jaxrs.JacksonJaxbJsonProvider;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

public class JerSeyClientGet2 {
	public static void main(String[] args) {
		ClientConfig config = new DefaultClientConfig();
	    config.getClasses().add(JacksonJaxbJsonProvider.class);
	    config.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

	    Client c = Client.create(config);
	    WebResource resource = c.resource("http://localhost:8080/apis/example");
	    ClientResponse response = resource.path("json2")
	            .accept("application/json").get(ClientResponse.class);
	    TestVO output = response.getEntity(TestVO.class);
	    
	    System.out.println(output.getName());
	}
}
