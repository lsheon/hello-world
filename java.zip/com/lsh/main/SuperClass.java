package com.lsh.main;

public class SuperClass {
	public static void main(String[] args) {
		SuperClass s = new SuperClass();
		
		s.print("hahaha");
	}
	
	public String a(String s1, String s2) {
		return "superClass.."+s1+", "+s2;
	}
	
	public void print(String s) {
		LowerClass l = new LowerClass();
		l.print(s);
	}
	
	private class LowerClass {
		public void print(String s) {
			String str = a("a","b");
			
			System.out.println(str+", lowerClass.."+s);
			
		}
	}
}
