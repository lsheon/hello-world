package com.lsh.main;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import com.lsh.UserAnnotation;

@UserAnnotation(number=0)
public class UserAnnotationSample 
{
    @UserAnnotation(number=1)
    public static void main(String[] args) {
    	UserAnnotationSample sample = new UserAnnotationSample();
        sample.checkAnnotations(UserAnnotationSample.class);
    }
 
    @UserAnnotation(number=2)
    public void annotationSample1(String s1, String s2, String s3) {
    	System.out.println("annotationSample1 call..."+s1+s2+s3);
    }
    @UserAnnotation(number=3, text="second")
    public void annotationSample2() {
    	System.out.println("annotationSample2 call...");
    }
    @UserAnnotation(number=4, text="third")
    public void annotationSample3() {
    	System.out.println("annotationSample3 call...");
    }
 
    public void checkAnnotations(Class<UserAnnotationSample> useClass){
    	for(Annotation annotation : useClass.getAnnotations()) {
    		UserAnnotation userAnnotation = (UserAnnotation)annotation;
    		//System.out.println(userAnnotation.number());
    	}
    	
    	
    	
        Method[] methods = useClass.getDeclaredMethods();
        for ( Method tempMethod:methods ){
            UserAnnotation annotation = tempMethod.getAnnotation(UserAnnotation.class);
            
            int number = 0;
            
            if ( annotation != null ){
                number = annotation.number();
                String text = annotation.text();
                System.out.println(tempMethod.getName() + "() : number=" + number + " text=" + text);
            } else {
                System.out.println(tempMethod.getName() + "() : annotation is null");
            }
            
            try{
            	if(number == 2) {
            		Object obj = useClass.newInstance();
            		Object o1 = "1";
            		Object o2 = "2";
            		Object o3 = "3";
            		
            		tempMethod.invoke(obj, o1, o2, o3);
            	}
            }catch(Exception e) {
            	e.printStackTrace();
            }
        }
    }
}
