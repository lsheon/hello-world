package com.lsh;

public class Test {
	public String print(String s) {
		System.out.println("print.... "+s);
		return "hi~ "+s;
	}
	
	public static void main(String[] args) {
		ClassLoader c = Thread.currentThread().getContextClassLoader();
		System.out.println("Class = " + c.getClass());
		System.out.println("Parent = " + c.getParent());
	}
}
