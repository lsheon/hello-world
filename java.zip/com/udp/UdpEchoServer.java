package com.udp;

import java.net.DatagramSocket;

public class UdpEchoServer {
	public static void main(String[] args) {
		int port = 7777;
		
		DatagramSocket dSocket = null;
		
		try{
			System.out.println("접속 대기 상태입니다.");
			dSocket = new DatagramSocket(port);
			
			String line = null;
			
			while(true) {
				byte[] buffer = new byte[1024];
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
