package com.nio;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyIOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			long startTime = System.currentTimeMillis();
			
			FileInputStream fis = new FileInputStream("D:/TEST/src.avi");
			FileOutputStream fos = new FileOutputStream("D:/TEST/dest.avi");
			
			//byte[] buf = new byte[fis.available()];
			byte[] buf = new byte[2048];
			
			while(fis.read(buf) != -1) {
				fos.write(buf);
			}
			
			//fis.read(buf);
			//fos.write(buf);
			
			System.out.println("Elapse Time : "+ (System.currentTimeMillis() - startTime));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
