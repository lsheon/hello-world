package com.nio;

public interface Queue {
	public Job pop(int eventType);
	public void push(Job job);
}
