package com.nio;

public class AdvancedchatServer {
	private Queue queue = null;
	private SelectorPoolIF acceptSelectorPool = null;
	private SelectorPoolIF requestSelectorPool = null;
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
