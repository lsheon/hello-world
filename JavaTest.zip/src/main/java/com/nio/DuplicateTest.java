package com.nio;

import java.nio.ByteBuffer;

public class DuplicateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteBuffer byteBuffer = ByteBuffer.allocate(10);
		
		byteBuffer.put((byte)0).put((byte)1).put((byte)2).put((byte)3).put((byte)4).put((byte)5)
		.put((byte)6).put((byte)7).put((byte)8).put((byte)9);
		
		System.out.println("byteBuffer.remaining() ?? "+byteBuffer.remaining());
		System.out.println("byteBuffer.hasRemaining() ?? "+byteBuffer.hasRemaining());
		
		byteBuffer.position(3);
		byteBuffer.limit(9);
		
		byteBuffer.mark();
		
		ByteBuffer byteBuffer2 = byteBuffer.duplicate();
		
		System.out.println("Position ?? "+byteBuffer2.position()+", Limit ?? "+byteBuffer2.limit()
		+", Capacity ?? "+byteBuffer2.capacity());
		
		byteBuffer2.position(7);
		byteBuffer2.reset();
		
		System.out.println("Position ?? "+byteBuffer2.position()+", Limit ?? "+byteBuffer2.limit()
		+", Capacity ?? "+byteBuffer2.capacity());
		
		byteBuffer2.clear();
		
		System.out.println("Position ?? "+byteBuffer2.position()+", Limit ?? "+byteBuffer2.limit()
		+", Capacity ?? "+byteBuffer2.capacity());
		
		while(byteBuffer2.hasRemaining()) {
			System.out.println(byteBuffer2.get()+" ");
		}
		
		byteBuffer.put(0, (byte)10);
		
		System.out.println("byteBuffer.get(0) ?? "+byteBuffer.get(0));
		System.out.println("byteBuffer2.get(0) ?? "+byteBuffer2.get(0));
	}

}
