package com.nio;

import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;

public class SimpleChannelTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadableByteChannel src = Channels.newChannel(System.in);
		WritableByteChannel desc = Channels.newChannel(System.out);
		
		ByteBuffer buffer = ByteBuffer.allocate(1024);
		
		try{
			while(src.read(buffer) != -1) {
				buffer.flip();
				
				while(buffer.hasRemaining()) {
					desc.write(buffer);
				}
				buffer.clear();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
