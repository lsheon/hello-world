/**
 * 
 */
package com.nio;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;

/**
 * @author lsh
 *
 */
public class SCConnectionTest {
	private static int PORT = 8080;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		InetAddress ia = InetAddress.getLocalHost();
		InetSocketAddress isa = new InetSocketAddress(ia, PORT);
		
		SocketChannel sc = SocketChannel.open();
		
		sc.configureBlocking(false);
		
		System.out.println("11 ? "+sc.isConnectionPending());
		
		sc.connect(isa);
		System.out.println("22 ? "+sc.isConnectionPending());
		
		sc.finishConnect();
		
		System.out.println("33 ? "+sc.isConnectionPending());
	}

}
