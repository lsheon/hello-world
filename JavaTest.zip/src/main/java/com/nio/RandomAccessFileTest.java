package com.nio;

import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class RandomAccessFileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			RandomAccessFile raf = new RandomAccessFile("D:/TEST/test.txt", "rw");
			RandomAccessFile raf2 = new RandomAccessFile("D:/TEST/test2.txt", "rw");
			
			FileChannel fc = raf.getChannel();
			
			ByteBuffer buffer = ByteBuffer.allocate(1024);
			
			System.out.println("position ?? "+buffer.position()+
					", limit ?? "+buffer.limit());
			
			fc.read(buffer,2);
			
			System.out.println("position ?? "+buffer.position()+
					", limit ?? "+buffer.limit());
			
			buffer.flip();
			
//			byte[] b = new byte[buffer.limit()];
//			
//			buffer.get(b);
//			
//			System.out.println(new String(b));
			
			FileChannel fc2 = raf2.getChannel();
			fc2.write(buffer, 0);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
