package com.nio;

import java.nio.ByteBuffer;

public class BulkReadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteBuffer buf = ByteBuffer.allocate(10);
		
		byte[] b = {1,2,3,4,5,6,7,8,9,10};
		
		buf.put((byte)99);
		
		buf.mark();
		
		buf.put(b,5,5);
		System.out.println("position 11 ?? "+buf.position());
		System.out.println("limit 11 ?? "+buf.limit());
		
		buf.reset();
		
		System.out.println("position 22 ?? "+buf.position());
		System.out.println("limit 22 ?? "+buf.limit());
		
		buf.flip();
		
		System.out.println("position 33 ?? "+buf.position());
		System.out.println("limit 33 ?? "+buf.limit());
		
		while(buf.hasRemaining()) {
			System.out.println(buf.get());
		}
		
	}

}
