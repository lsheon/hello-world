package com.io;

public class SystemInputTest {
	public static void main(String[] args) {
		//int i=0;
		
//		System.out.println("SystemInputTest");
//		
//		int a = 0x3131;
//		char cr = 0x0D;
//		
//		System.out.println("hahaha"+cr+"kkk");
//		System.out.println(a);
		
		try{
			//int test = 44032;
			
			//byte[] test = {-29, -124, -79};
			int[] test = {227, 132, 177};
			
			System.out.println("test ?? "+new String(test,0,3));
			
			byte b[] = new byte[1024];
			int j = 0;
			
			j = System.in.read(b);
			System.out.println(j);
			
			for(int i=0; i<j; i++) {
				System.out.println("byte ?? "+b[i]);
			}
			
			System.out.println("String ?? "+new String(b, "utf-8"));
			System.out.println("String ?? "+new String(b, "euc-kr"));
			System.out.println("String ?? "+new String(b, "ISO-8859-1"));
			
			///////////////////////////////////////////////
			
			int i=0;
			
			while((i = System.in.read()) != 10) {
				System.out.println("i ?? "+i);
				
				//System.out.write(i);
			}
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
