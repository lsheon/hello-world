package com.lsh;

import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.codehaus.jackson.jaxrs.JacksonJaxbJsonProvider;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class JerSeyClientGet4 {
	public static void main(String[] args) {
		ClientConfig config = new DefaultClientConfig();
	    config.getClasses().add(JacksonJaxbJsonProvider.class);
	    config.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

	    Client c = Client.create(config);
	    WebResource resource = c.resource("http://localhost:8080/apis/example")
	    		.queryParam("name", "hahaha");
	    
	    MultivaluedMap formData = new MultivaluedMapImpl();
	    formData.add("name", "hahaha");
	    
	    ClientResponse response = resource.path("json4")
	    		.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE)
	            .accept("application/json")
	            .post(ClientResponse.class, formData);

	    Map<String, String> output = response.getEntity(Map.class);
	    
	    System.out.println(output.get("name"));
	}
}
