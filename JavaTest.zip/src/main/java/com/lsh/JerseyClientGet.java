package com.lsh;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

public class JerseyClientGet {
	private static ClientConfig clientConfig = new DefaultClientConfig();
	
	 public static void main(String[] args) {
			try {
				clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
				
				Client client = Client.create(clientConfig);

				WebResource webResource = client.resource("http://localhost:8080/apis/example/json2");

				ClientResponse response = webResource.accept("application/json")
		                   .get(ClientResponse.class);

				if (response.getStatus() != 200) {
				   throw new RuntimeException("Failed : HTTP error code : "
					+ response.getStatus());
				}

				TestVO output = (TestVO)response.getEntity(TestVO.class);
				
				
				System.out.println("Output from Server .... \n");
				System.out.println(output.name);

			  } catch (Exception e) {

				e.printStackTrace();

			  }

	 }
}
