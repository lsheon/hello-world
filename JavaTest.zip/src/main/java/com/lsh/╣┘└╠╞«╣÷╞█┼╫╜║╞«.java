package com.lsh;

import java.nio.ByteBuffer;

public class 바이트버퍼테스트 {
	public static void main(String[] args) {
		
		try{
			ByteBuffer buffer = ByteBuffer.allocate(10);
			
			buffer.put((byte)1);
			buffer.put((byte)2);
			buffer.put((byte)3);
			
			buffer.limit(2);
			
			System.out.println(buffer.get());
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
