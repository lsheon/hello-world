package com.lsh.main;

import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLStreamHandler;

import com.lsh.Test;

public class MethodTestMain {
	public static void main(String[] args) {
		URL[] urls = new URL[1];
		
		URLStreamHandler uRLStreamHandler = null;
		
		try{
			urls[0] = new URL(null, "file://D:/workspace/JavaTest/target/classes/com/lsh/", uRLStreamHandler);
			
			URLClassLoader urlClassLoader = new URLClassLoader(urls);
			Class clazz = urlClassLoader.loadClass("com.lsh.Test");
			
			Object object = clazz.newInstance();
			Class paramTypes[] = new Class[1];
            paramTypes[0] = Class.forName("java.lang.String");
            Object paramValues[] = new Object[1];
            paramValues[0] = "lsh";
            
			Method method =
					object.getClass().getMethod("print", paramTypes);
	        
			Object result = method.invoke(object, paramValues);
			
			System.out.println(result);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
