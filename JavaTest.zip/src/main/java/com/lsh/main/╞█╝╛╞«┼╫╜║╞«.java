package com.lsh.main;

public class 퍼센트테스트 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1%2;
		
		System.out.println(i);
	}

}
