package com.lsh;

public class 한글바이트변환 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "a";
		
		byte[] b = s.getBytes();
		
		System.out.println(b.length);
		
		String s1 = "가";
		
		byte[] b1 = s1.getBytes();
		
		System.out.println(b1.length);
		
		Float f = Float.valueOf(2.5f);
		
		System.out.println("f ?? "+f);
		
		byte bb = f.byteValue();
		
		System.out.println("bb ?? "+bb);
	}

}
