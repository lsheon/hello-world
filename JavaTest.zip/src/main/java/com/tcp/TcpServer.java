package com.tcp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer {
	public static void main(String[] args) {
		try{
			ServerSocket serverSocket = new ServerSocket(10001);
			
			while(true) {
				final Socket socket = serverSocket.accept();
				final OutputStream out = socket.getOutputStream();
				final InputStream in = socket.getInputStream();
				
				Thread thread = new Thread() {
					public String parseProtocol(int protocolLen) throws IOException{
						byte[] readByte = new byte[protocolLen];
						int readByteCnt = 0;
						int len = protocolLen;
						int off = 0;
						
						while((readByteCnt += in.read(readByte, off, len)) != -1) {
							if(readByteCnt < protocolLen) {
								off = readByteCnt;
								len = protocolLen - readByteCnt;
							
								continue;
							}
							
							break;
						}
						
						return new String(readByte, 0, protocolLen);
					}
					
					public void run() {
						try{
							while(true) {
								String header = parseProtocol(3);
								
								System.out.println("header ?? "+header);
								
								String body = parseProtocol(5);
								
								System.out.println("body ?? "+body);
								
								String tail = parseProtocol(2);
								
								System.out.println("tail ?? "+tail);
								
								System.out.println("Packet ?? "+header+body+tail);
								
							}
						}catch(Exception e) {
							e.printStackTrace();
						}
					}
				};
				
				thread.start();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
