package com.tcp;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class 파싱테스트 {
	/**
     * Internal buffer.
     */
    protected byte buf[];
    
	/**
     * Last valid byte.
     */
    protected int count;

    /**
     * Position in the buffer.
     */
    protected int pos;
    
    /**
     * Underlying input stream.
     */
    protected InputStream is;
    
    /**
     * CR.
     */
    private static final byte CR = (byte) '\r';

    /**
     * LF.
     */
    private static final byte LF = (byte) '\n';
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			파싱테스트 test = new 파싱테스트();
			
			BufferedReader keyboard = new BufferedReader(
					new InputStreamReader(System.in));
			
			String line = null;
			
			test.buf = new byte[2048];
			
			while((line = keyboard.readLine()) != null) {
				test.is = new ByteArrayInputStream( line.getBytes() );
				test.execute();
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception{
		int chr = 0;
        do { // Skipping CR or LF
            try {
                chr = read();
                
                System.out.println("chr?? "+chr);
            } catch (IOException e) {
                chr = -1;
            }
        } while ((chr == CR) || (chr == LF));
        if (chr == -1) {
            throw new EOFException();
        }
	}
	
	public int read()
        throws IOException {
        if (pos >= count) {
            fill();
            if (pos >= count)
                return -1;
        }
        return buf[pos++] & 0xff;
    }
	
	protected void fill()
        throws IOException {
        pos = 0;
        count = 0;
        
        System.out.println("fill()...");
        System.out.println("buf.length ?? "+buf.length);
        
        
        int nRead = is.read(buf, 0, buf.length);
        if (nRead > 0) {
            count = nRead;
        }
        
        System.out.println("read ?? "+new String(buf, 0, buf.length));
    }

}
