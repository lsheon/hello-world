package com.tcp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class TcpClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Socket socket =new Socket("127.0.0.1", 10001);
			
			InputStream in = socket.getInputStream();
			OutputStream out = socket.getOutputStream();
			
			BufferedReader keyboard = new BufferedReader(
					new InputStreamReader(System.in));
					
			String line = null;
			
			int i = 300;
			
			System.out.println("i ?? "+i);
			
			out.write(i);
			
			int i2 = 500;
			
			System.out.println("i2 ?? "+i2);
			
			out.write(i2);
			
			int i3 = 44;
			
			System.out.println("i3 ?? "+i3);
			
			out.write(i3);
			
			int i4 = 111111;
			
			System.out.println("i4 ?? "+i4);
			
			out.write(i4);
			
//			byte b = 0x61;
//			
//			System.out.println("b ?? "+b);
//			
//			out.write(b);
			
//			String s = "0x61";
//			out.write(s.getBytes());
			
			out.flush();
			
//			String s = "2";
//			out.write(s.getBytes());
//			
//			int i = 50;
//			out.write(i);
//			
//			byte[] b = new byte[1];
//			b[0] = 2;
//			out.write(b);
//			out.flush();
			
			while( (line = keyboard.readLine()) != null ) {
				out.write(line.getBytes("utf-8"));
				out.flush();
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
