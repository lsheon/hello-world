package com.tcp;

public class 캐릭터셋테스트 {
	public static void main(String[] args) {
		
		try{
			String fileEncoding=System.getProperty("file.encoding"); 
			
			System.out.println("fileEncoding ?? "+fileEncoding);
			
			String str = "1";
			
			byte[]  bytes0  = str.getBytes();
			
			for(int i=0; i< bytes0.length; i++) {
				System.out.println("Default ?? "+bytes0[i]);
				
				System.out.println("Default Int ?? "+ (bytes0[i]&0xff));
			}
						
			
			
			byte[]  bytes  = str.getBytes("euc-kr");
			
			for(int i=0; i< bytes.length; i++) {
				System.out.println("EUC-KR ?? "+bytes[i]);
			}
			
			//iso-8859-1
			byte[]  bytes2  = str.getBytes("iso-8859-1");
			
			for(int i=0; i< bytes2.length; i++) {
				System.out.println("iso-8859-1 ?? "+bytes2[i]);
			}
			
			//utf-8
			byte[]  bytes3  = str.getBytes("utf-8");
			
			for(int i=0; i< bytes3.length; i++) {
				System.out.println("utf-8 ?? "+bytes3[i]);
			}
			
			byte[] test = new byte[6];
			test[0] = -22;
			test[1] = -80;
			test[2] = -128;
			test[3] = -21;
			test[4] = -126;
			test[5] = -104;
			
			System.out.println("11 "+new String(test, "utf-8"));
			
			byte[] test_euc_kr = new byte[2];
			test_euc_kr[0] = -80;
			test_euc_kr[1] = -95;		
			
			System.out.println("test_euc_kr "+new String(test_euc_kr, "euc-kr"));
			
			//euc-k : 176, 161
			//utf-8 : 234, 176, 128
			//iso-8859-1 : 63
			
			byte[] test11 = new byte[3];
			test11[0] = (byte)234;
			test11[1] = (byte)176;
			test11[2] = (byte)128;
			
			System.out.println("euc-kr 가?? "+new String(test11, "utf-8"));
			
			/*
			 가 :
			 utf-8 ?? -22
				utf-8 ?? -80
				utf-8 ?? -128 
			 */
			String hex = "ea";
			int intValue = Integer.parseInt( hex, 16 );
			
			System.out.println("int ?? "+intValue);
			System.out.println("byte ?? "+(byte)intValue);
			
			hex = "b0";
			intValue = Integer.parseInt( hex, 16 );
			
			System.out.println("int ?? "+intValue);
			System.out.println("byte ?? "+(byte)intValue);
			
			hex = "80";
			intValue = Integer.parseInt( hex, 16 );
			
			System.out.println("int ?? "+intValue);
			System.out.println("byte ?? "+(byte)intValue);

			int decimalValue = Integer.parseInt("11101010", 2);
			System.out.println("decimalValue ?? "+decimalValue);
			System.out.println("decimalValue byte ?? "+(byte)decimalValue);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
