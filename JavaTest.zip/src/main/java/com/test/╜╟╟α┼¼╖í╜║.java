package com.test;

public class 실행클래스 {
	public void a() {
		System.out.println("a");
	}
}
