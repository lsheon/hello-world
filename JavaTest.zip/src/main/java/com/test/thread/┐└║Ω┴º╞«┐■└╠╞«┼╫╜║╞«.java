package com.test.thread;

public class 오브젝트웨이트테스트 {
	public static void main(String[] args) {
//		Object obj = new Object();
//		
//		try{
//			synchronized(obj) {
//				obj.wait();
//			}			
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		
		final 싱크러나이즈드메서드테스트 obj = new 싱크러나이즈드메서드테스트();
		
		Thread t1 = new Thread() {
			public void run() {
				try{
					Thread.sleep(2000);
				}catch(Exception e) {
					e.printStackTrace();
				}
				obj.setS("hahaha");
			}
		};
		
		t1.start();
		
		Thread t2 = new Thread("t2") {
			public void run() {
				try{
					System.out.println(Thread.currentThread().getName()+" obj.getS() ?? "+obj.getS());
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		t2.start();
		
		Thread t3 = new Thread("t3") {
			public void run() {
				try{
					System.out.println(Thread.currentThread().getName()+" obj.getS() ?? "+obj.getS());
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		};		
		t3.start();
		t3.setPriority(Thread.MAX_PRIORITY);
				
	}
}
