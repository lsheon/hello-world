package com.test.thread;

public class 쓰레드로컬테스트 {
	static volatile int counter = 0;
	
	static ThreadLocal<String> threadLocal = new ThreadLocal<String>();	
	
	public static void display() {
		System.out.println("display()... "+threadLocal.get());
		System.out.println("counter ?? "+counter);
	}
	
	public static void main(String[] args) {
		final Object obj = new Object();
		
		Runnable runner = new Runnable() {
			public void run() {
				threadLocal.set(Thread.currentThread().getName());
				synchronized(Object.class) {
					counter++;
					display();
				}	
				
				//System.out.println("Thread name : "+threadLocal.get());
				
			}
		};
		
		for(int i=0; i<10000; i++) {
			Thread t = new Thread(runner);
			t.start();
		}
	}
	
}
