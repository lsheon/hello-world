package com.test.thread;

public class 죠인테스트쓰레드  extends Thread{
	public void run() {
		try{
			Thread.sleep(2000);
			System.out.println("죠인테스트쓰레드 종료");
			Thread.sleep(3000);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
