package com.test;

public class 실행클래스정의 {
	public static void main(String[] args) {
		실행클래스 a = new 실행클래스();
		a.a();		
		
		실행클래스 b = new 실행클래스() {
			public void a() {
				System.out.println("aa");
				b();
			}
			
			public void b() {
				System.out.println("b");
			}
		};
		b.a();
	}
}
