package com.lsh.controller;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.web.bind.annotation.RequestBody;

import com.lsh.vo.TestVO;

@Path("/example") 
public class JerseyTestController {

	@GET    
	@Produces(MediaType.TEXT_PLAIN) 
	@Path("/hello")     
	public String getHelloMessage(){       
		return "Hello, REST!";     
	}
	
	@GET    
	@Produces(MediaType.TEXT_PLAIN)     
	@Path("/account/userNum={id}&userName={name}")
	public String printParamValues(@PathParam("id") final int userNum, @PathParam("name") final String userName) {         
		return "User number : " + userNum + " name : " + userName;    		
	} 
	
	@GET    
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/json")
	public Response jsonObject(@PathParam("id") final int userNum, @PathParam("name") final String userName) {
		String json = "{name=lsh, age=40}";
		
		return Response.ok(json, MediaType.APPLICATION_JSON).build();
	}
	
	@GET    
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/json2")
	public TestVO jsonObject2() {
		System.out.println("jsonObject2 call..........");
		
		TestVO testVO = new TestVO();
		testVO.setAge("40");
		testVO.setName("lsh");
		return testVO;
	}
	
	@GET    
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/json3")
	public Map<String, String> jsonObject3() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", "lsh");
		return map;
	}
	
	@POST   
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/json4")
	public Map<String, String> jsonObject4(@RequestBody TestVO testVO) {
		System.out.println("testVO.getName() ?? "+testVO.getName());
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", testVO.getName());
		return map;
	}
}
