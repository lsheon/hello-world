package com.lsh.vo;

public class TestVO {
	public String name;
	public String age;
	
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "name ?? "+name+", age ?? "+age;
	}
}
